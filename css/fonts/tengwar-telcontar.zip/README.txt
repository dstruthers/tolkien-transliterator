-----------------------------------------------------------------

Tengwar Telcontar - a Unicode Tengwar font.
Version 0.08. Copyright (C) 2005-2009 Johan Winge.

This font is part of the Free Tengwar Font Project.

-----------------------------------------------------------------

Tengwar Telcontar is free software: you can redistribute it and/or
modify it under the terms of the GNU General Public License as
published by the Free Software Foundation, either version 3 of
the License, or (at your option) any later version.

As a special exception, if you create a document which uses this font,
and embed this font or unaltered portions of this font into the
document, this font does not by itself cause the resulting document
to be covered by the GNU General Public License. This exception does
not however invalidate any other reasons why the document might be
covered by the GNU General Public License. If you modify this font,
you may extend this exception to your version of the font, but you are
not obligated to do so. If you do not wish to do so, delete this
exception statement from your version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

-----------------------------------------------------------------

Tengwar Telcontar is a "smart" font and will need special software
to work correctly. For more information, see the web page of
the Free Tengwar Font Project: http://freetengwar.sourceforge.net/

The source code for this version can be downloaded with Subversion:
svn co https://freetengwar.svn.sourceforge.net/svnroot/freetengwar/tengtelc/tags/0.08/

If you want to contact me personally, I can be reached by the
following means:

Snail-mail:
 Johan Winge
 Bellmansgatan 62
 SE-754 26 Uppsala
 Sweden

E-mail:
 johan.winge@telia.com
